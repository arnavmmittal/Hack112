# Hack112 - Team redrawAll() presents Homerun Derby
My team made a home run derby game! When pressing the key 'p' the ball is pitched to you.
You have a chance of hitting a homerun if it makes contact with the bat.
To swing the bat the player must left click on the mouse. 
A person gets a total of 10 pitches before the game prompts you to restart. 


